import React from 'react';
import { Camera, MapPin } from 'lucide-react';

const StudentActionCard = ({ session, onScan }) => {
    // Default mock data if no session provided
    const safeSession = session || {
        courseName: "Advanced Architecture",
        room: "Room 302",
        time: "10:00 AM - 11:30 AM",
        mode: "OFFLINE",
        inRange: true
    };

    return (
        <div className="student-wallet-card">
            {/* Header */}
            <div className="wallet-header">
                <div className="wallet-header-pattern"></div>
                <div className="position-relative z-10 w-100">
                    <h2 className="text-white fs-4 fw-bold mb-1">{safeSession.courseName}</h2>
                    <p className="text-white opacity-75 small m-0">{safeSession.room} • {safeSession.time}</p>
                </div>
            </div>

            {/* Content */}
            <div className="wallet-content d-flex flex-column align-items-center">
                {safeSession.mode === 'OFFLINE' && (
                    <>
                        <div className="d-flex align-items-center gap-2 mb-4 text-muted small">
                            <span
                                className={`d-inline-block rounded-circle ${safeSession.inRange ? 'bg-success' : 'bg-danger'}`}
                                style={{ width: '10px', height: '10px', boxShadow: `0 0 10px ${safeSession.inRange ? 'rgba(34,197,94,0.5)' : 'rgba(239,68,68,0.5)'}` }}
                            ></span>
                            {safeSession.inRange ? "You are in the classroom" : "Move closer to Room 302"}
                        </div>

                        <button
                            disabled={!safeSession.inRange}
                            onClick={onScan}
                            className={`action-btn-large ${safeSession.inRange ? 'dark' : 'bg-gray-200 text-gray-400'}`}
                        >
                            <Camera size={24} />
                            Scan QR Code
                        </button>
                    </>
                )}

                {safeSession.mode === 'ONLINE' && (
                    <>
                        <div className="w-100 p-3 bg-primary bg-opacity-10 rounded-3 mb-4 border border-primary border-opacity-25">
                            <p className="text-primary small text-center m-0">
                                Attendance is tracked automatically based on your time in the meeting.
                            </p>
                        </div>
                        <button className="action-btn-large bg-primary text-white shadow">
                            Launch Zoom Class
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};

export default StudentActionCard;
