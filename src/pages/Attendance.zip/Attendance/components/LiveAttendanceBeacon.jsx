import React, { useState, useEffect } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { motion } from 'framer-motion';
// Note: Framer Motion is used for layout animations, but CSS animations handle the gradient bg.

const LiveAttendanceBeacon = () => {
    const [token, setToken] = useState("init_token");
    const [progress, setProgress] = useState(100);

    // Simulating the rotating token logic
    useEffect(() => {
        const interval = setInterval(() => {
            setToken(Math.random().toString(36));
            setProgress(100);
        }, 15000);

        // Update progress every 100ms
        // 15 seconds = 15000ms. 
        // Updating every 100ms, means 150 steps.
        // 100 / 150 = 0.666 decrement per step.
        const countdown = setInterval(() => setProgress((prev) => Math.max(0, prev - (100 / 150))), 100);

        return () => { clearInterval(interval); clearInterval(countdown); };
    }, []);

    return (
        <div className="glass-panel beacon-container overflow-hidden position-relative">
            {/* Background Animated Gradient is handled by parent or CSS classes on wrapper */}

            {/* The Beacon Content */}
            <div className="position-relative z-10 d-flex flex-column align-items-center w-100">
                <h2 className="beacon-title">Scan to Join</h2>

                {/* QR Wrapper with Progress Ring */}
                <div className="qr-wrapper">
                    <div
                        className="progress-border"
                        style={{ clipPath: `inset(0 0 ${100 - progress}% 0)` }} // CSS clip-path for progress effect
                    />
                    <QRCodeCanvas value={`https://lms.com/attend/${token}`} size={220} level={"H"} />
                </div>

                <p className="beacon-status">
                    Token refreshes in <span className="text-white fw-bold">{Math.ceil((progress / 100) * 15)}s</span>
                </p>

                <div className="status-badge-row">
                    <span className="status-badge green">
                        ● GPS Geofence Active
                    </span>
                    <span className="status-badge blue">
                        ● Wifi: Campus_Student
                    </span>
                </div>
            </div>
        </div>
    );
};

export default LiveAttendanceBeacon;
