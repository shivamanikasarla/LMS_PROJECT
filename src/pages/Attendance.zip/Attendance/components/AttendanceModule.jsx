import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react'; // Using SVG for sharper scaling
import {
    Scan,
    Wifi,
    MapPin,
    ShieldCheck,
    User,
    Clock,
    Activity,
    Zap,
    Users
} from 'lucide-react';
// import { clsx } from 'clsx';
// import { twMerge } from 'tailwind-merge';

// --- Utils ---
function cn(...inputs) {
    return inputs.filter(Boolean).join(' ');
}

// --- Components ---

const BackgroundWrapper = ({ children }) => {
    return (
        <div className="relative w-full min-h-[600px] overflow-hidden rounded-3xl bg-slate-950 p-6 md:p-12 font-sans select-none">
            {/* Deep Space Gradient Background */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/40 via-slate-950 to-slate-950" />

            {/* Animated Floating Orbs */}
            <motion.div
                animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3],
                    x: [0, 50, 0],
                    y: [0, -30, 0]
                }}
                transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-600/20 blur-[120px] rounded-full mix-blend-screen pointer-events-none"
            />
            <motion.div
                animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.2, 0.4, 0.2],
                    x: [0, -30, 0],
                    y: [0, 50, 0]
                }}
                transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 2 }}
                className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-indigo-600/10 blur-[100px] rounded-full mix-blend-screen pointer-events-none"
            />

            {/* Grid Pattern Overlay */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-150 contrast-150 pointer-events-none mix-blend-overlay"></div>

            <div className="relative z-10 w-full h-full flex flex-col md:flex-row gap-8">
                {children}
            </div>
        </div>
    );
};

const InstructorBeacon = () => {
    const [token, setToken] = useState("init-token");
    const [progress, setProgress] = useState(100);
    const [glitch, setGlitch] = useState(false);

    // Heartbeat Effect: Refresh QR Logic
    useEffect(() => {
        const interval = setInterval(() => {
            setGlitch(true);
            setTimeout(() => {
                setToken(Math.random().toString(36).substring(7));
                setProgress(100);
                setGlitch(false);
            }, 300); // 300ms glitch duration
        }, 15000); // 15 seconds

        const countdown = setInterval(() => {
            setProgress(prev => Math.max(0, prev - (100 / (15 * 10)))); // Decrease smoothly
        }, 100);

        return () => {
            clearInterval(interval);
            clearInterval(countdown);
        };
    }, []);

    return (
        <motion.div
            className="flex-1 min-h-[450px] flex items-center justify-center"
            animate={{ y: [0, -15, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        >
            <div className="relative w-full max-w-md bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl flex flex-col items-center overflow-hidden group">
                {/* Glow Effect on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

                {/* Header */}
                <div className="flex items-center gap-3 mb-8 w-full">
                    <div className="p-3 rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.3)]">
                        <Scan size={24} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white tracking-wide">Secure Check-In</h2>
                        <p className="text-indigo-200/60 text-xs font-mono uppercase tracking-widest">Beacon Active • Room 302</p>
                    </div>
                    <div className="ml-auto">
                        <motion.div
                            animate={{ opacity: [0.5, 1, 0.5] }}
                            transition={{ duration: 2, repeat: Infinity }}
                            className="w-3 h-3 bg-emerald-400 rounded-full shadow-[0_0_10px_#34d399]"
                        />
                    </div>
                </div>

                {/* QR Section */}
                <div className="relative z-10 mb-8 p-1">
                    {/* Ring Container */}
                    <div className="relative w-64 h-64 flex items-center justify-center">
                        {/* SVG Progress Ring */}
                        <svg className="absolute inset-0 w-full h-full -rotate-90">
                            <circle
                                cx="128" cy="128" r="120"
                                fill="transparent"
                                stroke="rgba(255,255,255,0.05)"
                                strokeWidth="4"
                            />
                            <motion.circle
                                cx="128" cy="128" r="120"
                                fill="transparent"
                                stroke="#6366f1"
                                strokeWidth="4"
                                strokeDasharray="753" // 2 * PI * 120
                                strokeDashoffset={753 - (753 * progress) / 100}
                                strokeLinecap="round"
                                className="drop-shadow-[0_0_8px_rgba(99,102,241,0.8)]"
                            />
                        </svg>

                        {/* The QR Code */}
                        <div className={cn("bg-white p-4 rounded-3xl transition-all duration-200", glitch && "blur-sm scale-95 opacity-80")}>
                            <QRCodeSVG value={token} size={160} level="H" />
                        </div>
                    </div>

                    <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
                        <p className="text-xs font-mono text-indigo-300/80 bg-black/40 px-3 py-1 rounded-full border border-white/5 backdrop-blur-md">
                            Refreshing in {Math.ceil((progress / 100) * 15)}s
                        </p>
                    </div>
                </div>

                {/* HUD Stats */}
                <div className="w-full grid grid-cols-2 gap-3 mt-auto">
                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 flex items-center gap-3 hover:bg-white/10 transition-colors">
                        <ShieldCheck size={18} className="text-emerald-400" />
                        <div className="flex flex-col">
                            <span className="text-[10px] uppercase text-indigo-200/50 font-bold">Security</span>
                            <span className="text-xs text-white font-medium">Geo-Fencing On</span>
                        </div>
                    </div>
                    <div className="bg-white/5 border border-white/5 rounded-xl p-3 flex items-center gap-3 hover:bg-white/10 transition-colors">
                        <Wifi size={18} className="text-cyan-400" />
                        <div className="flex flex-col">
                            <span className="text-[10px] uppercase text-indigo-200/50 font-bold">Network</span>
                            <span className="text-xs text-white font-medium">Campus_5G</span>
                        </div>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};

const LiveStream = () => {
    const [attendees, setAttendees] = useState([
        { id: 1, name: "Sarah Connor", avatar: "S", time: "10:00:05", status: "On Time" },
        { id: 2, name: "John Wick", avatar: "J", time: "10:01:20", status: "On Time" },
        { id: 3, name: "Tony Stark", avatar: "T", time: "10:02:45", status: "Late" }
    ]);

    // Simulating Live Attendees
    useEffect(() => {
        const names = ["Peter Parker", "Bruce Wayne", "Clark Kent", "Diana Prince", "Wanda Maximoff", "Steve Rogers"];
        const interval = setInterval(() => {
            const randomName = names[Math.floor(Math.random() * names.length)];
            const isLate = Math.random() > 0.8;

            const newStudent = {
                id: Date.now(),
                name: randomName,
                avatar: randomName.charAt(0),
                time: new Date().toLocaleTimeString('en-US', { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }),
                status: isLate ? "Late" : "On Time"
            };

            setAttendees(prev => [newStudent, ...prev].slice(0, 7)); // Keep last 7
        }, 3500);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex-1 flex flex-col h-[500px]">
            <div className="flex items-center justify-between mb-6 px-2">
                <h3 className="text-white font-bold text-lg flex items-center gap-2">
                    <Activity size={20} className="text-pink-500 animate-pulse" />
                    Live Feed
                </h3>
                <div className="flex items-center gap-2 text-indigo-300 bg-indigo-950/50 px-3 py-1 rounded-full border border-indigo-500/20 shadow-inner">
                    <Users size={14} />
                    <span className="text-sm font-mono font-bold">{attendees.length} <span className="opacity-50 font-normal">/ 45</span></span>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-hide perspective-[1000px]">
                <AnimatePresence initial={false}>
                    {attendees.map((student, i) => (
                        <motion.div
                            key={student.id}
                            initial={{ opacity: 0, x: 50, rotateX: -15 }}
                            animate={{ opacity: 1, x: 0, rotateX: 0 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            transition={{ type: "spring", stiffness: 300, damping: 20 }}
                            className={cn(
                                "relative group flex items-center gap-4 p-4 rounded-2xl border backdrop-blur-md transition-all duration-300",
                                "bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/20 hover:scale-[1.02] hover:shadow-[0_8px_30px_rgba(0,0,0,0.3)]",
                                // "Glass Shard" look
                            )}
                        >
                            {/* Avatar */}
                            <div className="relative">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-lg">
                                    {student.avatar}
                                </div>
                                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full ring-2 ring-emerald-500/20" />
                            </div>

                            <div className="flex-1">
                                <h4 className="text-white font-semibold text-sm group-hover:text-indigo-200 transition-colors">{student.name}</h4>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[11px] text-indigo-300/60 font-mono bg-indigo-950/30 px-1.5 py-0.5 rounded border border-indigo-500/10">
                                        ID: {Math.floor(Math.random() * 9000) + 1000}
                                    </span>
                                </div>
                            </div>

                            <div className="flex flex-col items-end gap-1">
                                <div className="flex items-center gap-1.5">
                                    <Clock size={12} className="text-indigo-400" />
                                    <span className="text-xs font-mono text-indigo-300">{student.time}</span>
                                </div>
                                {student.status === "Late" && (
                                    <span className="px-2 py-0.5 bg-rose-500/20 text-rose-300 text-[10px] font-bold uppercase tracking-wider rounded border border-rose-500/20 shadow-[0_0_10px_rgba(244,63,94,0.2)]">
                                        LATE
                                    </span>
                                )}
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
};

// --- Main Module Export ---

const AttendanceModule = () => {
    return (
        <BackgroundWrapper>
            <InstructorBeacon />
            <LiveStream />
        </BackgroundWrapper>
    );
};

export default AttendanceModule;
