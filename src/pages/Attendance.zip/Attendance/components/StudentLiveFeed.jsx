import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const StudentLiveFeed = ({ attendees = [] }) => {
    // If empty, we can show a placeholder or empty state
    // But for "Live" feel, let's allow it to be empty initially

    const scrollRef = useRef(null);

    // Auto-scroll to top when new attendee arrives
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = 0;
        }
    }, [attendees]);

    return (
        <div className="glass-panel live-feed-container" ref={scrollRef}>
            <div className="feed-header">
                <h3 className="text-white font-semibold m-0 fs-5">Live Arrivals</h3>
                <span className="text-secondary font-mono text-xl">{attendees.length} <span className="text-sm">checked in</span></span>
            </div>

            <div className="d-flex flex-column gap-2">
                <AnimatePresence initial={false}>
                    {attendees.map((student) => (
                        <motion.div
                            key={student.id || student.studentId} // Use reliable key
                            initial={{ opacity: 0, x: 20, height: 0 }}
                            animate={{ opacity: 1, x: 0, height: 'auto' }}
                            exit={{ opacity: 0, x: -20, height: 0 }}
                            transition={{ type: "spring", stiffness: 300, damping: 30 }}
                            className="feed-item"
                        >
                            {student.avatar ? (
                                <img src={student.avatar} alt={student.name} className="feed-avatar" />
                            ) : (
                                <div className="feed-avatar-placeholder">{student.name.charAt(0)}</div>
                            )}

                            <div className="flex-grow-1">
                                <p className="text-white text-sm font-medium m-0 fw-bold">{student.name}</p>
                                <p className="text-secondary text-xs m-0 d-flex align-items-center gap-1 small">
                                    {student.method === 'Online' ? '🌐 Zoom API' : '📍 Geo-verified'}
                                    • {student.time || 'Just now'}
                                </p>
                            </div>

                            {student.status === 'Late' && (
                                <span className="badge bg-warning text-dark text-xs fw-bold px-2 py-1 rounded">LATE</span>
                            )}
                        </motion.div>
                    ))}
                </AnimatePresence>

                {attendees.length === 0 && (
                    <div className="text-center text-secondary mt-5 opacity-50">
                        <p>Waiting for students to join...</p>
                        <div className="spinner-border spinner-border-sm" role="status"></div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default StudentLiveFeed;
