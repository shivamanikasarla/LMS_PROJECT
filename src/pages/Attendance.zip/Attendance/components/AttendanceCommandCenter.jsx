import React, { useState, useEffect } from 'react';
import LiveAttendanceBeacon from './LiveAttendanceBeacon';
import StudentLiveFeed from './StudentLiveFeed';
import StudentActionCard from './StudentActionCard';
import '../styles/attendance-advanced.css';

// Mock Data for the Command Center
const MOCK_LIVE_ARRIVALS = [
    { id: 1, name: "Alice Johnson", time: "10:02 AM", method: "GPS", status: "Present", avatar: "" },
    { id: 2, name: "Bob Smith", time: "10:05 AM", method: "QR", status: "Late", avatar: "" },
];

const AttendanceCommandCenter = () => {
    // Simulator State
    const [attendees, setAttendees] = useState([]);
    const [viewRole, setViewRole] = useState('INSTRUCTOR'); // INSTRUCTOR or STUDENT

    // Simulate arriving students
    useEffect(() => {
        let currentIndex = 0;
        const interval = setInterval(() => {
            if (currentIndex < MOCK_LIVE_ARRIVALS.length) {
                setAttendees(prev => [MOCK_LIVE_ARRIVALS[currentIndex], ...prev]);
                currentIndex++;
            } else {
                // Reset for demo loop
                // setAttendees([]);
                // currentIndex = 0;
                clearInterval(interval);
            }
        }, 5000); // New student every 5s

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="advanced-attendance-wrapper mb-5">
            <div className="animated-gradient-bg"></div>

            <div className="position-relative z-10">

                {/* Header / Toggle for Demo */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                    <h2 className="text-white font-bold m-0 text-xl tracking-wide">
                        {viewRole === 'INSTRUCTOR' ? 'Mission Control' : 'Student Wallet'}
                    </h2>

                    <div className="bg-white/10 p-1 rounded-pill d-flex gap-1" style={{ backdropFilter: 'blur(4px)', border: '1px solid rgba(255,255,255,0.1)' }}>
                        <button
                            className={`btn btn-sm text-xs rounded-pill px-3 fw-bold ${viewRole === 'INSTRUCTOR' ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:text-white'}`}
                            onClick={() => setViewRole('INSTRUCTOR')}
                            style={{ background: viewRole === 'INSTRUCTOR' ? '#6366f1' : 'transparent', border: 'none' }}
                        >
                            Instructor
                        </button>
                        <button
                            className={`btn btn-sm text-xs rounded-pill px-3 fw-bold ${viewRole === 'STUDENT' ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:text-white'}`}
                            onClick={() => setViewRole('STUDENT')}
                            style={{ background: viewRole === 'STUDENT' ? '#6366f1' : 'transparent', border: 'none' }}
                        >
                            Student
                        </button>
                    </div>
                </div>

                {viewRole === 'INSTRUCTOR' ? (
                    <div className="row g-4">
                        {/* Left Panel: Beacon */}
                        <div className="col-lg-7">
                            <LiveAttendanceBeacon />
                        </div>

                        {/* Right Panel: Live Stream */}
                        <div className="col-lg-5">
                            <StudentLiveFeed attendees={attendees} />
                        </div>
                    </div>
                ) : (
                    <div className="d-flex justify-content-center align-items-center py-5">
                        <StudentActionCard
                            onScan={() => {
                                // Demo Action
                                setAttendees(prev => [{
                                    id: Date.now(),
                                    name: "You (Demo)",
                                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                                    method: "QR",
                                    status: "Present"
                                }, ...prev]);
                                alert("Scanned Successfully! Check Instructor View.");
                            }}
                        />
                    </div>
                )}

            </div>
        </div>
    );
};

export default AttendanceCommandCenter;
