import React, { useState, useEffect } from 'react';

const AnalogClock = () => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const secondsStyle = {
        transform: `rotate(${time.getSeconds() * 6}deg)`
    };
    const minutesStyle = {
        transform: `rotate(${time.getMinutes() * 6 + time.getSeconds() * 0.1}deg)`
    };
    const hoursStyle = {
        transform: `rotate(${time.getHours() * 30 + time.getMinutes() * 0.5}deg)`
    };

    return (
        <div className="clock-container mb-3">
            <div className="clock-face">
                <div className="clock-center"></div>
                <div className="hand hour-hand" style={hoursStyle}></div>
                <div className="hand minute-hand" style={minutesStyle}></div>
                <div className="hand second-hand" style={secondsStyle}></div>

                {/* Clock markings */}
                {[...Array(12)].map((_, i) => (
                    <div key={i} className="clock-marker" style={{ transform: `rotate(${i * 30}deg) translateY(-40px)` }}>|</div>
                ))}
            </div>
            <div className="digital-time mt-3 fw-bold text-primary fs-5">
                {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}
            </div>
        </div>
    );
};

const CalendarWidget = () => {
    const days = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

    // Simple dynamic calendar for current month
    const today = new Date();
    const currentMonth = today.toLocaleString('default', { month: 'long', year: 'numeric' });
    const currentDay = today.getDate();

    const dates = useCalendarDates(today); // We would implement a proper hook here, but for now mocking dynamic active state

    return (
        <div className="calendar-widget h-100 p-3">
            <div className="d-flex justify-content-center align-items-center mb-4">
                <h6 className="fw-bold m-0 text-dark">{currentMonth}</h6>
            </div>

            <div className="d-grid" style={{ gridTemplateColumns: 'repeat(7, 1fr)', gap: '8px', textAlign: 'center' }}>
                {days.map(d => (
                    <div key={d} className="text-secondary small fw-bold mb-2" style={{ fontSize: '12px' }}>{d}</div>
                ))}

                {dates.map((d, i) => (
                    <div
                        key={i}
                        className={`
                            calendar-date 
                            ${d.prevMonth || d.nextMonth ? 'text-muted opacity-50' : 'text-dark'} 
                            ${d.date === currentDay && !d.prevMonth && !d.nextMonth ? 'bg-primary text-white rounded-circle shadow-sm' : ''}
                        `}
                        style={{
                            width: '32px',
                            height: '32px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '13px',
                            fontWeight: '500',
                            margin: '0 auto',
                            cursor: 'pointer'
                        }}
                    >
                        {d.date}
                    </div>
                ))}
            </div>
        </div>
    );
};

// Simplified hook helper for calendar dates
function useCalendarDates(date) {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay(); // 0 = Sun
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Adjust for Monday start
    const startOffset = firstDay === 0 ? 6 : firstDay - 1;

    const dates = [];
    // Prev month filler
    for (let i = 0; i < startOffset; i++) {
        dates.push({ date: '', prevMonth: true }); // simplified
    }
    // Current month
    for (let i = 1; i <= daysInMonth; i++) {
        dates.push({ date: i, prevMonth: false });
    }
    // Next month filler
    while (dates.length < 35) { // 5 rows
        dates.push({ date: '', nextMonth: true });
    }
    return dates;
}

const AttendanceTracker = ({ session, onPunch }) => {
    // Helper to format milliseconds to HH Hr MM Mins SS Secs
    const formatDuration = (ms) => {
        const seconds = Math.floor((ms / 1000) % 60);
        const minutes = Math.floor((ms / (1000 * 60)) % 60);
        const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);

        return `${hours} Hr ${String(minutes).padStart(2, '0')} Mins ${String(seconds).padStart(2, '0')} Secs`;
    };

    return (
        <div className="mb-4">
            <h5 className="fw-bold text-dark mb-3">Attendance</h5>

            <div className="row g-4">
                {/* Calendar Section */}
                <div className="col-md-4">
                    <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', overflow: 'hidden' }}>
                        <div className="card-body">
                            <CalendarWidget />
                        </div>
                    </div>
                </div>

                {/* Clock & Action Section */}
                <div className="col-md-8">
                    <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px' }}>
                        <div className="card-body p-4">
                            <div className="row align-items-center h-100">
                                {/* Clock */}
                                <div className="col-md-5 text-center border-end">
                                    <style>{`
                                        .clock-face {
                                            width: 140px;
                                            height: 140px;
                                            border-radius: 50%;
                                            background: #eef2ff;
                                            position: relative;
                                            border: 4px solid #fff;
                                            box-shadow: 0 0 20px rgba(0,0,0,0.05); /* Soft shadow */
                                            margin: 0 auto;
                                        }
                                        .clock-center {
                                            width: 10px;
                                            height: 10px;
                                            background: #6366f1;
                                            border-radius: 50%;
                                            position: absolute;
                                            top: 50%;
                                            left: 50%;
                                            transform: translate(-50%, -50%);
                                            z-index: 10;
                                        }
                                        .hand {
                                            position: absolute;
                                            bottom: 50%;
                                            left: 50%;
                                            transform-origin: bottom center;
                                            border-radius: 4px;
                                        }
                                        .hour-hand {
                                            width: 4px;
                                            height: 35px;
                                            background: #1e293b;
                                            z-index: 5;
                                        }
                                        .minute-hand {
                                            width: 3px;
                                            height: 50px;
                                            background: #94a3b8;
                                            z-index: 4;
                                        }
                                        .second-hand {
                                            width: 1px;
                                            height: 55px;
                                            background: #ef4444;
                                            z-index: 6;
                                        }
                                    `}</style>
                                    <AnalogClock />
                                </div>

                                {/* Stats & Action */}
                                <div className="col-md-7 ps-md-4">
                                    <div className="d-flex flex-column gap-3">
                                        {/* Working Hours */}
                                        <div className="p-3 border rounded-3 bg-white">
                                            <div className="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <small className="text-secondary fw-bold text-uppercase" style={{ fontSize: '11px' }}>Working Hours</small>
                                                    <h5 className="mb-0 fw-bold text-dark mt-1">
                                                        {formatDuration(session.elapsedTime)}
                                                    </h5>
                                                </div>
                                                {session.status === 'SignedIn' && (
                                                    <div className="spinner-grow text-success spinner-grow-sm" role="status"></div>
                                                )}
                                            </div>
                                        </div>

                                        {/* Break Hours (Static for now, can be wired similarly) */}
                                        <div className="p-3 border rounded-3 bg-white">
                                            <div className="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <small className="text-secondary fw-bold text-uppercase" style={{ fontSize: '11px' }}>Break Hours</small>
                                                    <h5 className="mb-0 fw-bold text-dark mt-1">0 Hr 00 Mins 00 Secs</h5>
                                                </div>

                                                <div style={{ width: '60px', height: '60px' }} className="d-none d-lg-block">
                                                    <div className="w-100 h-100 d-flex align-items-center justify-content-center text-success bg-success bg-opacity-10 rounded-circle">
                                                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 20h10" /><path d="M10 20c5.5-2.5.8-6.4 3-10" /><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z" /><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z" /></svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Punch Button */}
                                        <div className="mt-2 d-flex gap-2">
                                            <button className="btn btn-outline-secondary p-2 d-flex align-items-center justify-content-center" style={{ width: '48px' }}>
                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                            </button>
                                            <button
                                                className={`btn flex-grow-1 fw-bold text-white shadow-sm ${session.status === 'SignedIn' ? 'btn-danger' : 'btn-success'}`}
                                                style={{
                                                    background: session.status === 'SignedIn' ? '#ef4444' : '#65a30d',
                                                    borderColor: session.status === 'SignedIn' ? '#ef4444' : '#65a30d'
                                                }}
                                                onClick={onPunch}
                                            >
                                                {session.status === 'SignedIn' ? 'Punch Out' : 'Punch In'}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AttendanceTracker;
