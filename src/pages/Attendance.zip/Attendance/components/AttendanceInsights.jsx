import React from 'react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

const mockData = [
    { name: '1', value: 30 },
    { name: '2', value: 45 },
    { name: '3', value: 35 },
    { name: '4', value: 50 },
    { name: '5', value: 45 },
    { name: '6', value: 60 },
    { name: '7', value: 55 },
];

const mockDataLate = [
    { name: '1', value: 20 },
    { name: '2', value: 30 },
    { name: '3', value: 25 },
    { name: '4', value: 40 },
    { name: '5', value: 35 },
    { name: '6', value: 20 },
    { name: '7', value: 15 },
];

const InsightCard = ({ title, value, subValue, trend, trendValue, color, icon: Icon, data }) => {
    const colors = {
        success: { stroke: "#22c55e", fill: "#dcfce7" },
        danger: { stroke: "#ef4444", fill: "#fee2e2" },
        warning: { stroke: "#f59e0b", fill: "#fef3c7" },
        info: { stroke: "#3b82f6", fill: "#dbeafe" },
    };

    const theme = colors[color] || colors.info;

    return (
        <div className="col-md-3">
            <div className="card border-0 shadow-sm h-100 overflow-hidden" style={{ borderRadius: '16px' }}>
                <div className="card-body p-3">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <p className="text-muted small fw-bold text-uppercase mb-1" style={{ fontSize: '11px', letterSpacing: '0.5px' }}>{title}</p>
                            <h3 className="fw-bolder mb-0 text-dark">{value}</h3>
                            {subValue && <p className="text-muted small mb-0 mt-1">{subValue}</p>}
                        </div>
                        {Icon && <div className={`p-2 rounded-circle bg-${color} bg-opacity-10 text-${color}`}>
                            <Icon size={18} />
                        </div>}
                    </div>

                    <div className="d-flex align-items-end justify-content-between">
                        <div style={{ width: '100%', height: '50px' }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={data}>
                                    <defs>
                                        <linearGradient id={`gradient-${color}`} x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor={theme.fill} stopOpacity={0.8} />
                                            <stop offset="95%" stopColor={theme.fill} stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <Area
                                        type="monotone"
                                        dataKey="value"
                                        stroke={theme.stroke}
                                        strokeWidth={2}
                                        fillOpacity={1}
                                        fill={`url(#gradient-${color})`}
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                    <div className="mt-2 text-xs font-weight-bold" style={{ fontSize: '11px' }}>
                        <span className={trend === 'up' ? 'text-success' : 'text-danger'}>
                            {trend === 'up' ? '↑' : '↓'} {trendValue}
                        </span>
                        <span className="text-muted ms-1">Compared to Jan</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

const AttendanceInsights = ({ stats }) => {
    // Default stats if not provided (fallback)
    const safeStats = stats || {
        onTimePct: 65,
        latePct: 35,
        totalBreak: "00 Hrs",
        totalWorking: "00 Hrs"
    };

    return (
        <div className="mb-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="fw-bold text-dark m-0">Insights</h5>
                <div className="bg-white border rounded-pill px-3 py-1 text-sm fw-bold text-muted shadow-sm d-flex align-items-center gap-2">
                    <span>2023</span>
                    <span className="text-gray-300">|</span>
                    <span>Current</span>
                </div>
            </div>

            <div className="row g-3">
                <InsightCard
                    title="On Time Percentage"
                    value={`${safeStats.onTimePct}%`}
                    trend="down"
                    trendValue="2%"
                    color="success"
                    data={mockData}
                />

                <InsightCard
                    title="Late Percentage"
                    value={`${safeStats.latePct}%`}
                    trend="up"
                    trendValue="5%"
                    color="danger"
                    data={mockDataLate}
                />

                <InsightCard
                    title="Total Break Hours"
                    value={safeStats.totalBreak}
                    subValue="Avg 40m / Day"
                    trend="down"
                    trendValue="13%"
                    color="warning"
                    data={mockData}
                />

                <InsightCard
                    title="Total Working Hours"
                    value={safeStats.totalWorking}
                    subValue="Target: 160 Hrs"
                    trend="up"
                    trendValue="12%"
                    color="info"
                    data={mockDataLate}
                />
            </div>
        </div>
    );
};

export default AttendanceInsights;
