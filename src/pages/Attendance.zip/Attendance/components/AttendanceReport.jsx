import React, { useState } from 'react';
import { FiCalendar, FiClock, FiCheckCircle, FiXCircle, FiAlertCircle, FiDownload, FiFilter } from 'react-icons/fi';

const AttendanceReport = ({ history = [] }) => {
    const [filter, setFilter] = useState('All');

    const getStatusBadge = (status) => {
        switch (status) {
            case 'Present': return <span className="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-3">Present</span>;
            case 'Absent': return <span className="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 rounded-pill px-3">Absent</span>;
            case 'Late': return <span className="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25 rounded-pill px-3">Late</span>;
            default: return <span className="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-25 rounded-pill px-3">{status}</span>;
        }
    };

    return (
        <div className="card border-0 shadow-sm rounded-4 overflow-hidden mt-4">
            <div className="card-header bg-white border-bottom p-4 d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h5 className="mb-1 fw-bold text-dark">Attendance History</h5>
                    <p className="text-muted small mb-0">Detailed view of daily attendance logs.</p>
                </div>
                <div className="d-flex gap-2">
                    <div className="dropdown">
                        <button className="btn btn-outline-secondary btn-sm d-flex align-items-center gap-2" type="button">
                            <FiFilter /> Filter: {filter}
                        </button>
                    </div>
                    <button className="btn btn-outline-primary btn-sm d-flex align-items-center gap-2">
                        <FiDownload /> Export CSV
                    </button>
                </div>
            </div>

            <div className="table-responsive">
                <table className="table table-hover align-middle mb-0">
                    <thead className="bg-light">
                        <tr>
                            <th className="py-3 px-4 text-secondary small text-uppercase">Date</th>
                            <th className="py-3 px-4 text-secondary small text-uppercase text-center">Status</th>
                            <th className="py-3 px-4 text-secondary small text-uppercase text-center">Check In</th>
                            <th className="py-3 px-4 text-secondary small text-uppercase text-center">Check Out</th>
                            <th className="py-3 px-4 text-secondary small text-uppercase text-center">Duration</th>
                            <th className="py-3 px-4 text-secondary small text-uppercase">Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        {history.length > 0 ? (
                            history.map((row) => (
                                <tr key={row.id}>
                                    <td className="px-4">
                                        <div className="d-flex flex-column">
                                            <span className="fw-semibold text-dark">{row.date}</span>
                                            <span className="text-muted small">{row.day}</span>
                                        </div>
                                    </td>
                                    <td className="px-4 text-center">
                                        {getStatusBadge(row.status)}
                                    </td>
                                    <td className="px-4 text-center font-monospace text-secondary">
                                        {row.checkIn}
                                    </td>
                                    <td className="px-4 text-center font-monospace text-secondary">
                                        {row.checkOut}
                                    </td>
                                    <td className="px-4 text-center fw-bold text-dark">
                                        {row.duration}
                                    </td>
                                    <td className="px-4 text-muted small">
                                        {row.remarks}
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="6" className="text-center py-5 text-muted">
                                    No attendance records found. Start by punching in!
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Mobile View (Card List) for extra responsiveness if table breaks */}
            <div className="d-md-none p-3">
                {/* Stacked View Logic could go here */}
            </div>

            <div className="card-footer bg-white border-top p-3">
                <div className="d-flex justify-content-between align-items-center">
                    <span className="text-muted small">Showing {history.length} records</span>
                    <nav>
                        <ul className="pagination pagination-sm mb-0">
                            <li className="page-item disabled"><a className="page-link" href="#">Previous</a></li>
                            <li className="page-item active"><a className="page-link" href="#">1</a></li>
                            <li className="page-item"><a className="page-link" href="#">Next</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    );
};

export default AttendanceReport;
