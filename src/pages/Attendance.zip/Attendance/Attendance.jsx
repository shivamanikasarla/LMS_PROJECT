import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MOCK_COURSES, MOCK_BATCHES } from './data/mockData';
import AttendanceTab from '../Batches/tabs/AttendanceTab';
import '../Batches/styles/BatchBuilder.css'; // Import shared styles
import './styles/attendance.css'; // Import local overrides if any
import AttendanceInsights from './components/AttendanceInsights';
import AttendanceTracker from './components/AttendanceTracker';
import AttendanceReport from './components/AttendanceReport';
import AttendanceModule from './components/AttendanceModule';
// import AttendanceCommandCenter from './components/AttendanceCommandCenter'; // Keeping as reference or removed

const Attendance = () => {
    const [selectedCourseId, setSelectedCourseId] = useState('');
    const [selectedBatchId, setSelectedBatchId] = useState('');

    // --- Dynamic State for Student Workflow ---
    // In a real app, this would be fetched from backend based on the logged-in user
    const [attendanceHistory, setAttendanceHistory] = useState([
        { id: 101, date: '2023-02-01', day: 'Wednesday', checkIn: '09:00 AM', checkOut: '05:00 PM', duration: '8h 0ms', status: 'Present', remarks: '-' },
        { id: 102, date: '2023-02-02', day: 'Thursday', checkIn: '09:15 AM', checkOut: '05:15 PM', duration: '8h 0m', status: 'Late', remarks: 'Traffic' },
        { id: 103, date: '2023-02-03', day: 'Friday', checkIn: '09:00 AM', checkOut: '04:30 PM', duration: '7h 30m', status: 'Present', remarks: 'Early Leave' },
    ]);

    const [currentSession, setCurrentSession] = useState({
        status: 'SignedOut', // SignedOut, SignedIn, OnBreak
        startTime: null,
        breakStartTime: null,
        totalBreakTime: 0, // in milliseconds
        elapsedTime: 0 // in milliseconds
    });

    // Timer Logic for Working Hours
    useEffect(() => {
        let interval;
        if (currentSession.status === 'SignedIn') {
            interval = setInterval(() => {
                const now = new Date();
                const start = new Date(currentSession.startTime);
                const elapsed = now - start - currentSession.totalBreakTime;
                setCurrentSession(prev => ({ ...prev, elapsedTime: elapsed }));
            }, 1000);
        } else if (currentSession.status === 'OnBreak') {
            // Optional: Track break duration explicitly if needed
        }
        return () => clearInterval(interval);
    }, [currentSession.status, currentSession.startTime, currentSession.totalBreakTime]);


    const handlePunchAction = () => {
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
        const dateString = now.toISOString().split('T')[0];
        const dayString = now.toLocaleDateString('en-US', { weekday: 'long' });

        if (currentSession.status === 'SignedOut') {
            // Punch In
            setCurrentSession({
                status: 'SignedIn',
                startTime: now,
                breakStartTime: null,
                totalBreakTime: 0,
                elapsedTime: 0
            });
            // We don't add to history yet, we wait for punch out to complete the record or we add a "processing" record.
            // For simplicity, let's just track current session live.
        } else if (currentSession.status === 'SignedIn') {
            // Punch Out
            // Calculate final duration
            const durationMs = currentSession.elapsedTime;
            const hours = Math.floor(durationMs / 3600000);
            const minutes = Math.floor((durationMs % 3600000) / 60000);

            const newRecord = {
                id: Date.now(),
                date: dateString,
                day: dayString,
                checkIn: currentSession.startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }),
                checkOut: timeString,
                duration: `${hours}h ${minutes}m`,
                status: 'Present', // Logic for late can be added if we had shift times
                remarks: '-'
            };

            setAttendanceHistory(prev => [newRecord, ...prev]);

            // Reset Session
            setCurrentSession({
                status: 'SignedOut',
                startTime: null,
                breakStartTime: null,
                totalBreakTime: 0,
                elapsedTime: 0
            });
        }
    };

    // Calculate Dynamic Stats for Insights
    const dynamicStats = useMemo(() => {
        // Calculate total working hours from history
        let totalWorkingSeconds = 0;
        attendanceHistory.forEach(record => {
            const parts = record.duration.match(/(\d+)h (\d+)m/);
            if (parts) {
                totalWorkingSeconds += (parseInt(parts[1]) * 3600) + (parseInt(parts[2]) * 60);
            }
        });

        // Format Total Working Hours
        const tHours = Math.floor(totalWorkingSeconds / 3600);
        const tMinutes = Math.floor((totalWorkingSeconds % 3600) / 60);

        return {
            onTimePct: 65, // dynamic calculation requires shift logic, keeping static base + variance if needed
            latePct: 35,
            totalBreak: "00 Hrs", // Placeholder unless we track break history deeper
            totalWorking: `${tHours} Hrs ${tMinutes} Mins`
        };
    }, [attendanceHistory]);


    // --- Existing Logic ---
    const filteredBatches = useMemo(() => {
        return MOCK_BATCHES.filter(b => b.courseId === selectedCourseId);
    }, [selectedCourseId]);

    const handleCourseChange = (e) => {
        setSelectedCourseId(e.target.value);
        setSelectedBatchId('');
    };

    const batchStats = useMemo(() => {
        if (!selectedBatchId) return null;
        return {
            totalStudents: 42,
            avgAttendance: 85,
            totalSessions: 12,
            lastSessionRate: 90
        };
    }, [selectedBatchId]);

    return (
        <div className="attendance-page-wrapper">
            <header className="page-header mb-4">
                <div className="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-800">Attendance Module</h1>
                        <p className="text-gray-500 mt-1">Manage student attendance across all active courses and batches.</p>
                    </div>
                </div>
            </header>

            {/* "Anti-Gravity" Attendance Module */}
            <AttendanceModule />

            <div className="my-5"></div>

            {/* Global Insights - Dynamic Props */}
            <AttendanceInsights stats={dynamicStats} />

            {/* Student Tracker - Dynamic Props */}
            <AttendanceTracker
                session={currentSession}
                onPunch={handlePunchAction}
            />

            {/* Attendance Report History - Dynamic Props */}
            <AttendanceReport history={attendanceHistory} />

            <div className="my-4 border-top"></div>

            {/* Global Context Selector */}
            <div className="gradient-header-card mb-4">
                <div className="row g-3">
                    <div className="col-md-6">
                        <label className="form-label-modern">1. Select Course</label>
                        <select
                            className="form-select-modern"
                            value={selectedCourseId}
                            onChange={handleCourseChange}
                        >
                            <option value="">-- Choose Course --</option>
                            {MOCK_COURSES.map(course => (
                                <option key={course.id} value={course.id}>{course.title}</option>
                            ))}
                        </select>
                    </div>
                    <div className="col-md-6">
                        <label className="form-label-modern">2. Select Batch</label>
                        <select
                            className="form-select-modern"
                            value={selectedBatchId}
                            onChange={(e) => setSelectedBatchId(e.target.value)}
                            disabled={!selectedCourseId}
                        >
                            <option value="">-- Choose Batch --</option>
                            {filteredBatches.map(batch => (
                                <option key={batch.id} value={batch.id}>{batch.name}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            {/* Batch Stats Overlay */}
            {selectedBatchId && batchStats && (
                <div className="row g-3 mb-4">
                    <div className="col-md-3">
                        <div className="card shadow-sm border-0 h-100 p-3 d-flex align-items-center gap-3 flex-row">
                            <div className="p-3 bg-primary bg-opacity-10 text-primary rounded-circle">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                            </div>
                            <div>
                                <h3 className="m-0 fw-bold">{batchStats.totalStudents}</h3>
                                <p className="m-0 text-muted small text-uppercase fw-bold">Active Students</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card shadow-sm border-0 h-100 p-3 d-flex align-items-center gap-3 flex-row">
                            <div className="p-3 bg-success bg-opacity-10 text-success rounded-circle">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                            </div>
                            <div>
                                <h3 className="m-0 fw-bold">{batchStats.avgAttendance}%</h3>
                                <p className="m-0 text-muted small text-uppercase fw-bold">Avg. Attendance</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card shadow-sm border-0 h-100 p-3 d-flex align-items-center gap-3 flex-row">
                            <div className="p-3 bg-warning bg-opacity-10 text-warning rounded-circle">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                            </div>
                            <div>
                                <h3 className="m-0 fw-bold">{batchStats.totalSessions}</h3>
                                <p className="m-0 text-muted small text-uppercase fw-bold">Total Sessions</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="card shadow-sm border-0 h-100 p-3 d-flex align-items-center gap-3 flex-row">
                            <div className="p-3 bg-info bg-opacity-10 text-info rounded-circle">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><activity></activity><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                            </div>
                            <div>
                                <h3 className="m-0 fw-bold">{batchStats.lastSessionRate}%</h3>
                                <p className="m-0 text-muted small text-uppercase fw-bold">Last Session</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Attendance Tab Content */}
            {selectedBatchId ? (
                <div className="fade-in-up">
                    <AttendanceTab batchId={selectedBatchId} showAdvancedControls={true} />
                </div>
            ) : (
                <div className="att-empty-state">
                    <div className="mb-3 p-4 bg-light rounded-circle text-primary mx-auto" style={{ width: 'fit-content' }}>
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="8.5" cy="7" r="4"></circle>
                            <polyline points="17 11 19 13 23 9"></polyline>
                        </svg>
                    </div>
                    <h3 className="text-gray-700 fw-bold mt-3">Ready to Mark Attendance?</h3>
                    <p className="text-muted max-w-md mx-auto">Please select a <strong>Course</strong> and <strong>Batch</strong> from the dropdowns above to load the session list and student registry.</p>
                </div>
            )}
        </div>
    );
};

export default Attendance;
